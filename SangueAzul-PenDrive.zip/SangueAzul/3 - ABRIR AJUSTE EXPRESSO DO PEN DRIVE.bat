@echo off
powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0sangue-azul.ps1" -Modo abrir -App ajuste
