@echo off
title Sangue Azul - Desinstalar
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0sangue-azul.ps1" -Modo desinstalar
pause
