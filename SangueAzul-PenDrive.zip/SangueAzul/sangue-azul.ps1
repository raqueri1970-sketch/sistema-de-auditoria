# Sangue Azul - Portal Esposende (versao portatil)
# Modos: instalar | abrir | desinstalar
# O portal roda num mini-servidor local (http://localhost:8765) para funcionar
# igual ao site: login salvo, uploads e verificacao de versao.
param([ValidateSet('instalar','abrir','desinstalar','servidor')][string]$Modo = 'abrir',
      [ValidateSet('portal','ajuste')][string]$App = 'portal',
      [string]$Raiz = '',
      [int]$Porta = 0)

$ErrorActionPreference = 'Stop'
# porta 8765 = instalado no PC | 8766 = rodando direto do pen drive
if ($Porta -eq 0) { $Porta = if ($PSScriptRoot -ieq (Join-Path $env:LOCALAPPDATA 'SangueAzul')) { 8765 } else { 8766 } }
$origem  = $PSScriptRoot
$destino = Join-Path $env:LOCALAPPDATA 'SangueAzul'
$desktop = [Environment]::GetFolderPath('Desktop')
$menu    = Join-Path ([Environment]::GetFolderPath('Programs')) 'Sangue Azul'
$paginas = @{ portal = 'index.html'; ajuste = 'ajuste.html' }

function Get-Navegador {
    $candidatos = @(
        "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
        "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
        "$env:LOCALAPPDATA\Microsoft\Edge\Application\msedge.exe",
        "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
        "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
        "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
    )
    foreach ($c in $candidatos) { if ($c -and (Test-Path $c)) { return $c } }
    throw 'Nenhum navegador Edge ou Chrome encontrado neste PC.'
}

function Test-Servidor {
    try {
        $r = Invoke-WebRequest -UseBasicParsing -TimeoutSec 2 "http://localhost:$Porta/__sangue_azul"
        return ($r.Content -eq 'ok')
    } catch { return $false }
}

$tipos = @{
    '.html'='text/html; charset=utf-8'; '.htm'='text/html; charset=utf-8'
    '.js'='application/javascript; charset=utf-8'; '.css'='text/css; charset=utf-8'
    '.json'='application/json'; '.webmanifest'='application/manifest+json'
    '.svg'='image/svg+xml'; '.png'='image/png'; '.jpg'='image/jpeg'; '.jpeg'='image/jpeg'
    '.gif'='image/gif'; '.webp'='image/webp'; '.ico'='image/x-icon'
    '.mp4'='video/mp4'; '.webm'='video/webm'; '.pdf'='application/pdf'; '.txt'='text/plain; charset=utf-8'
}

function Start-Servidor([string]$pastaApp) {
    $sep = [IO.Path]::DirectorySeparatorChar
    $raizCompleta = [IO.Path]::GetFullPath($pastaApp).TrimEnd($sep) + $sep
    $http = New-Object Net.HttpListener
    $http.Prefixes.Add("http://localhost:$Porta/")
    $http.Start()
    while ($http.IsListening) {
        $ctx = $http.GetContext()
        $res = $ctx.Response
        try {
            $caminho = [Uri]::UnescapeDataString($ctx.Request.Url.AbsolutePath)
            if ($caminho -eq '/__sangue_azul') {
                $bytes = [Text.Encoding]::ASCII.GetBytes('ok')
            } else {
                if ($caminho.EndsWith('/')) { $caminho += 'index.html' }
                $arquivo = [IO.Path]::GetFullPath((Join-Path $raizCompleta $caminho.TrimStart('/')))
                if (-not $arquivo.StartsWith($raizCompleta, [StringComparison]::OrdinalIgnoreCase) -or
                    -not (Test-Path -LiteralPath $arquivo -PathType Leaf)) {
                    $res.StatusCode = 404
                    $bytes = [Text.Encoding]::UTF8.GetBytes('Arquivo nao encontrado')
                } else {
                    $ext = [IO.Path]::GetExtension($arquivo).ToLower()
                    $res.ContentType = if ($tipos.ContainsKey($ext)) { $tipos[$ext] } else { 'application/octet-stream' }
                    $res.Headers.Add('Cache-Control', 'no-cache')
                    $bytes = [IO.File]::ReadAllBytes($arquivo)
                }
            }
            $res.ContentLength64 = $bytes.Length
            $res.OutputStream.Write($bytes, 0, $bytes.Length)
        } catch {
            $res.StatusCode = 500
        } finally {
            $res.OutputStream.Close()
        }
    }
}

function Open-App([string]$pastaBase, [string]$qual) {
    $pastaApp = Join-Path $pastaBase 'app'
    if (-not (Test-Servidor)) {
        # sobe o servidor escondido em segundo plano
        Start-Process -WindowStyle Hidden -FilePath 'powershell.exe' -ArgumentList @(
            '-NoProfile','-ExecutionPolicy','Bypass','-WindowStyle','Hidden',
            '-File',"`"$PSCommandPath`"",'-Modo','servidor','-Porta',$Porta,'-Raiz',"`"$pastaApp`"")
        for ($i = 0; $i -lt 40 -and -not (Test-Servidor); $i++) { Start-Sleep -Milliseconds 250 }
    }
    $url = "http://localhost:$Porta/$($paginas[$qual])"
    Start-Process -FilePath (Get-Navegador) -ArgumentList "--app=$url"
}

switch ($Modo) {
    'servidor' { Start-Servidor $Raiz }
    'abrir'    { Open-App $origem $App }
    'desinstalar' {
        Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" |
            Where-Object { $_.CommandLine -like '*sangue-azul.ps1*-Modo servidor*' } |
            ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
        Remove-Item -Recurse -Force $destino, $menu -ErrorAction SilentlyContinue
        Remove-Item -Force (Join-Path $desktop 'Portal Esposende.lnk'), (Join-Path $desktop 'Ajuste Expresso.lnk') -ErrorAction SilentlyContinue
        Write-Host 'Sangue Azul removido deste PC.' -ForegroundColor Yellow
    }
    'instalar' {
        $nav = Get-Navegador
        Write-Host "Navegador: $nav"
        Write-Host "Copiando arquivos para $destino ..."
        Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" |
            Where-Object { $_.CommandLine -like '*sangue-azul.ps1*-Modo servidor*-Porta 8765*' } |
            ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
        if (Test-Path $destino) { Remove-Item -Recurse -Force $destino }
        New-Item -ItemType Directory -Force -Path $destino | Out-Null
        Copy-Item -Recurse -Force (Join-Path $origem 'app') $destino
        Copy-Item -Force (Join-Path $origem '*.ico'), (Join-Path $origem 'sangue-azul.ps1') $destino
        New-Item -ItemType Directory -Force -Path $menu | Out-Null

        $script = Join-Path $destino 'sangue-azul.ps1'
        $shell  = New-Object -ComObject WScript.Shell
        $atalhos = @(
            @{ Nome = 'Portal Esposende'; App = 'portal'; Icone = 'sangue-azul.ico' },
            @{ Nome = 'Ajuste Expresso';  App = 'ajuste'; Icone = 'ajuste.ico' }
        )
        foreach ($a in $atalhos) {
            foreach ($pasta in @($desktop, $menu)) {
                $lnk = $shell.CreateShortcut((Join-Path $pasta "$($a.Nome).lnk"))
                $lnk.TargetPath       = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
                $lnk.Arguments        = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$script`" -Modo abrir -App $($a.App)"
                $lnk.IconLocation     = (Join-Path $destino $a.Icone) + ',0'
                $lnk.WorkingDirectory = $destino
                $lnk.WindowStyle      = 7
                $lnk.Description      = "$($a.Nome) - Sangue Azul"
                $lnk.Save()
            }
        }
        Write-Host ''
        Write-Host 'INSTALADO COM SUCESSO!' -ForegroundColor Green
        Write-Host 'Atalhos criados na Area de Trabalho e no Menu Iniciar:'
        Write-Host '  - Portal Esposende  (icone Sangue Azul)'
        Write-Host '  - Ajuste Expresso'
        & $script -Modo abrir -App portal
    }
}
