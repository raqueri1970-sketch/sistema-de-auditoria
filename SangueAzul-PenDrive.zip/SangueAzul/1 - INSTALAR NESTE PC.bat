@echo off
title Sangue Azul - Instalador
echo Instalando o Portal Esposende (Sangue Azul)...
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0sangue-azul.ps1" -Modo instalar
echo.
pause
